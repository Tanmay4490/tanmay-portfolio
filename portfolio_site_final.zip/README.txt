Portfolio Website Package
-------------------------
Files included:
- index.html        : Main single-page portfolio
- styles.css       : Simple responsive styles
- script.js        : Smooth-scroll helper
- README.txt       : This file

How to use:
1. Unzip the package.
2. Edit index.html to replace [Your Name], contact info, and project details with your real information.
3. Upload the folder to any static web host (GitHub Pages, Netlify, Vercel) or open index.html locally in your browser.

Notes:
- Replace placeholder email and phone before sharing publicly.
- If you'd like, I can generate a version with your real name, contact details, or host it live for you (if you provide hosting access).
